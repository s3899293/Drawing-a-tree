let img;

function preload(){
  img = loadImage('Tree Leaves.png');
   
}
// environment setup and green grass rectangle
function setup() {
  createCanvas(displayWidth, displayHeight);
  strokeWeight(20);
  stroke(255,255,0);
  fill(255,255,0);
  fill(15,140,15)
  stroke(15,140,15)
  rect(0,400,8000,40);
  fill(255,255,0)
}
// tree leaves 
function draw(){
  image(img,250,0,400,400);
}

// drawing the tree trunk
function mouseDragged() {
  line(mouseX, mouseY, pmouseX, pmouseY);
  stroke(127,81,18)
  fill(127,81,18)
  return false;
}

//sun in the sky
function mousePressed(){
  line(mouseX, mouseY, pmouseX, pmouseY);
  stroke(255,255,0)
  fill(255,255,0)
  strokeWeight(50)
  return false;
}
